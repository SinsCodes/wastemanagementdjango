from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

from . import views
# from mainpro import settings

urlpatterns = [
    path('index/', views.index),
    path('rest/', views.rest_base),
    path('login/', views.login),
    path('add_res/', views.add_res),
    path('add_ngo/', views.add_ngo),
    path('ad_view/', views.admin_view),
    path('view_rest/', views.view_rest),
    path('view_ngo/', views.view_ngo),
    path('list_ngo/', views.list_ngo),
    path('list_rest/', views.list_rest),
    path('del_rest/', views.delete_resdata),
    path('del_ngo/', views.del_ngodata),
    path('index_log/', views.index_login),
    path('logout_res/', views.logout_res),
    path('logout_ngo/', views.logout_ngo),
    path('logout_admin/', views.logout_admin),
    path('employee_add/', views.employee_add),
    path('employee_reg/', views.employee_reg),
    path('employee_list/', views.employee_list),
    path('up_ngo/',views.upload_ngo),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
